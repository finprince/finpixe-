import sys
import os
from .core import optimize_file

def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: rim-optimize [--dynamic] <file1.py> [file2.py ...]")
        sys.exit(0)
        
    dynamic_mode = False
    if "--dynamic" in args:
        dynamic_mode = True
        args.remove("--dynamic")
        
    files = args
    optimized_count = 0
    for f in files:
        if os.path.exists(f) and f.endswith(".py"):
            if optimize_file(f, dynamic=dynamic_mode):
                optimized_count += 1
                
    if optimized_count > 0:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
