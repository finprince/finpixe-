import sys
import os
import ast
import time

class PowerToMultMutator(ast.NodeTransformer):
    """Mutates x ** 2 into x * x"""
    def visit_BinOp(self, node):
        self.generic_visit(node)
        if isinstance(node.op, ast.Pow):
            if isinstance(node.right, ast.Constant) and node.right.value == 2:
                # Replace x ** 2 with x * x
                new_node = ast.BinOp(
                    left=node.left,
                    op=ast.Mult(),
                    right=node.left
                )
                return ast.copy_location(new_node, node)
        return node

class LoopToListCompMutator(ast.NodeTransformer):
    """Mutates a simple for-loop append into a list comprehension."""
    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        new_body = []
        i = 0
        while i < len(node.body):
            stmt = node.body[i]
            
            # Look for: result = [] \n for x in data: ... \n return result
            if isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.value, ast.List) and len(stmt.value.elts) == 0:
                list_var_name = getattr(stmt.targets[0], 'id', None)
                if not list_var_name:
                    new_body.append(stmt)
                    i += 1
                    continue
                
                if i + 2 < len(node.body) and isinstance(node.body[i+1], ast.For) and isinstance(node.body[i+2], ast.Return):
                    for_node = node.body[i+1]
                    return_node = node.body[i+2]
                    
                    if getattr(return_node.value, 'id', None) == list_var_name:
                        # We have the pattern! Let's build the list comp.
                        target_expr = None
                        ifs = []
                        
                        body = for_node.body
                        if len(body) == 1 and isinstance(body[0], ast.If):
                            if_node = body[0]
                            ifs.append(if_node.test)
                            body = if_node.body
                            
                        if len(body) == 1 and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Call):
                            call = body[0].value
                            if isinstance(call.func, ast.Attribute) and call.func.attr == 'append' and getattr(call.func.value, 'id', None) == list_var_name:
                                if call.args:
                                    target_expr = call.args[0]
                                
                        if target_expr:
                            # Build the list comprehension
                            comp = ast.ListComp(
                                elt=target_expr,
                                generators=[
                                    ast.comprehension(
                                        target=for_node.target,
                                        iter=for_node.iter,
                                        ifs=ifs,
                                        is_async=0
                                    )
                                ]
                            )
                            # Replace the 3 statements with a direct return
                            new_return = ast.Return(value=comp)
                            ast.copy_location(new_return, return_node)
                            new_body.append(new_return)
                            i += 3
                            continue
            new_body.append(stmt)
            i += 1
        node.body = new_body
        return node

class SetLookupMutator(ast.NodeTransformer):
    """Mutates x in [1, 2, 3] to x in {1, 2, 3}"""
    def visit_Compare(self, node):
        self.generic_visit(node)
        if len(node.ops) == 1 and isinstance(node.ops[0], ast.In):
            if len(node.comparators) == 1 and isinstance(node.comparators[0], ast.List):
                # Convert the List to a Set
                list_node = node.comparators[0]
                # Only convert if the list has elements
                if list_node.elts:
                    set_node = ast.Set(elts=list_node.elts)
                    node.comparators[0] = ast.copy_location(set_node, list_node)
        return node

class GeneratorMemoryMutator(ast.NodeTransformer):
    """Mutates sum([x for x in y]) to sum(x for x in y)"""
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id in {'sum', 'max', 'min', 'any', 'all'}:
            if len(node.args) == 1 and isinstance(node.args[0], ast.ListComp):
                list_comp = node.args[0]
                gen_exp = ast.GeneratorExp(
                    elt=list_comp.elt,
                    generators=list_comp.generators
                )
                node.args[0] = ast.copy_location(gen_exp, list_comp)
        return node

class IsNoneMutator(ast.NodeTransformer):
    """Mutates x == None to x is None and x != None to x is not None"""
    def visit_Compare(self, node):
        self.generic_visit(node)
        if len(node.ops) == 1 and len(node.comparators) == 1:
            op = node.ops[0]
            comp = node.comparators[0]
            if isinstance(op, (ast.Eq, ast.NotEq)):
                if isinstance(comp, ast.Constant) and comp.value is None:
                    new_op = ast.Is() if isinstance(op, ast.Eq) else ast.IsNot()
                    new_node = ast.Compare(
                        left=node.left,
                        ops=[new_op],
                        comparators=[comp]
                    )
                    return ast.copy_location(new_node, node)
        return node

def profile_dynamic(source_code, label):
    start = time.perf_counter()
    env = {}
    try:
        exec(source_code, env)
    except Exception as e:
        print(f"[!] Dynamic execution failed for {label}: {e}")
        return -1
    return time.perf_counter() - start

def optimize_source(source, dynamic=False):
    """
    Takes a raw string of Python code and returns the optimized string.
    Returns (optimized_source_string, was_mutated)
    """
    try:
        tree = ast.parse(source)
        original_unparsed = ast.unparse(tree)
        
        mutators = [PowerToMultMutator(), LoopToListCompMutator(), SetLookupMutator(), GeneratorMemoryMutator(), IsNoneMutator()]
        
        mutated_tree = tree
        for mutator in mutators:
            mutated_tree = mutator.visit(mutated_tree)
            
        ast.fix_missing_locations(mutated_tree)
        new_unparsed = ast.unparse(mutated_tree)
        
        if original_unparsed != new_unparsed:
            # Verify it compiles
            compile(mutated_tree, filename="<ast>", mode="exec")
            
            if dynamic:
                orig_time = profile_dynamic(original_unparsed, "Original")
                new_time = profile_dynamic(new_unparsed, "Mutated")
                if orig_time != -1 and new_time != -1:
                    if new_time > orig_time:
                        return source, False
                elif new_time == -1:
                    return source, False
            
            return new_unparsed, True
            
    except Exception as e:
        print(f"[!] RIM AST Parsing/Mutation Error: {e}")
        
    return source, False

def optimize_file(filepath, dynamic=False):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            source = f.read()
            
        new_source, mutated = optimize_source(source, dynamic)
        
        if mutated:
            # Write back
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(new_source)
            print(f"[*] RIM Optimized: {filepath}")
            return True
            
    except Exception as e:
        print(f"[!] RIM Error on {filepath}: {e}")
        
    return False
